from bs4 import BeautifulSoup
import requests
import pandas as pd
from pandas import DataFrame

url = 'https://colombia.as.com/resultados/futbol/clasificacion_mundial_sudamerica/2018/clasificacion/?omnil=src-sab'

page = requests.get(url)

soup = BeautifulSoup(page.content, 'html.parser')

"""Equipos de futbol"""

eq = soup.find_all('span', class_='nombre-equipo')

print(eq)

equipos = list()

count = 0

for i in eq:
    if count < 20:
        equipos.append(i.text)

    else:
        break
        count += 1


"""Goles Equipo"""

td = soup.find_all('td', class_='destacado')

print(td)

Goles = list()

count = 0

for i in td:
    if count < 20:
        Goles.append(i.text)

    else:
        break
        count += 1

df= pd.DataFrame(('Nombre': equipos,'Goles':Goles), index=list(range(1.21)))

df.to_csv('Clasificacion.csv', index=False)
print(Goles)





